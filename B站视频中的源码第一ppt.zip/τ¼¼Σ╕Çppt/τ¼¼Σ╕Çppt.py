import requests
from lxml import etree


def get_urls(url):
    #请求数据
    headers={
        "User-Agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36"
    }
    response=requests.get(url=url,headers=headers).text
    #解析数据
    detail_urls=[]
    html=etree.HTML(response)
    urls=html.xpath("//ul[@class='tplist']/li/a/@href")
    for i in urls:
        detail_urls.append("http://www.1ppt.com/"+i)


    for down_url_page in detail_urls:
        down_page=requests.get(url=down_url_page,headers=headers).text
        down_url=etree.HTML(down_page)
        downurllist=down_url.xpath("//ul[@class='downurllist']/li/a/@href")[0]
        title=downurllist.split("/")[-1]
        doc=requests.get(downurllist,headers).content
        fp=open("浪漫ppt模板/"+title,"wb")
        fp.write(doc)
        print(title+"爬取成功！！！！")

def make_urls():
    for i in range(1,9):
        url="http://www.1ppt.com/moban/aiqing/ppt_aiqing_{}.html".format(i)
        get_urls(url)
        print("第{}页模板爬取成功".format(i))
    print("所以ppt模板爬取成功！！！")



if __name__ == '__main__':
    make_urls()




